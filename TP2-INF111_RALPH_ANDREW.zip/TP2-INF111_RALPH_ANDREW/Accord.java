package musique;

/*
 * @author Ralph Kobersy et Andrew Kobersy 
 * @version H2020
 * 
 * Strategie
 * Voici la classe Accord, cette classe accord a plusieurs constructeurs et
 * methodes qui permettent de creer des accords et de les faire jouer par 
 * la suite.
 */

import java.util.ArrayList;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;


public class Accord{
	
	/*
	 * Attribut privee de la classe Accord 
	 */
	private String accord;
	private ArrayList<Note>  Notes;
	
	/*
	 * Constructeur par defaut 
	 * 
	 * @param aucun parametre
	 * 
	 * @return aucun retour 
	 */
	public Accord() {
		
		initAccord();
	}
	/*
	 * Constructeur par copie d'attribut 
	 * 
	 * Recoit un tableau de note et met chacune des notes dans la collection
	 * 
	 * @param accord de type String 
	 * 
	 * @param tabNoteRecu qui est un tableau de note
	 */
	public Accord(String accord, Note[] tabNoteRecu) {
		
		//On copie l'accord dans l'attribut de la classe
		this.accord=accord;
		
		//On initialise la collection de note
		Notes = new ArrayList<Note>();
		
		//Iterateur qui va parcourir le tableau de note
		int i=0;
		
		//Tant qu'on a pas fini de lire le tableau de note et 
		//que le tableau de note n'est pas null
		while(tabNoteRecu != null && i<tabNoteRecu.length) {
			
			//On rajoute la note dans la collection de note 
			Notes.add(tabNoteRecu[i]);
			
			//On incremente l'iterateur
			++i;
			
		}

	}
	
	/*
	 * Accesseur qui permet d'obtenir les notes
	 * 
	 * @param aucun parametre
	 * 
	 * @return Notes qui est une collection de note
	 */
	public ArrayList<Note> getNote(){
		
		return Notes;
	}
	
	/*
	 * Accesseur d'accord
	 * 
	 * @param aucun parametre
	 * 
	 * @return on retourne l'accord
	 */
	public String getAccord() {
		
		return accord;
	}
	/*
	 * Mutateur pour accord
	 * 
	 * @param Accord qui est un String 
	 * 
	 * Permet de donner un nom a l'accord
	 * 
	 * @return aucun retour
	 */
	public void setAccord(String accord) {
		
		this.accord=accord;
		
	}
	/*
	 * Methode de comparaison 
	 * 
	 * @param obj de type Object
	 * 
	 * @return retourne si c'est vrai ou faux
	 */
	@Override
	public boolean equals(Object accord) {
		
		//On retourne si le nom de l'accord est le meme
		return ((Accord)accord).accord.equals(this.accord);

	}
	
	/*
	 * Methode qui permet d'afficher la collection de notes.
	 * 
	 * @param pas de parametres
	 * 
	 * @return retourne une collection de notes dans une variable nomAccord
	 */
	public String afficherTableauAccord() {
		
		//Initialisation de la valeur de retour 
		String nomAccord="";
		
		//Bouble qui parcourt la collection de l'accord et qui affiche
		//la note selon la position de l'iterateur
		for(int i=0;i< Notes.size();++i) {
			
			//A chaque tour de boucle, la variable retient la note 
			//dans une chaine de caractere
			nomAccord= ("\t"+Notes.get(i));
		
		}
		
		//Retourne la chaine de caractere
		return nomAccord;
	}
	
	/*
	 * Methode de debogage toString
	 * 
	 * Permet d'afficher le resultat
	 * 
	 * @param aucun param
	 * 
	 * @return une chaine de String
	 * 
	 */
	public String toString() {
		
		//Retourne la chaine de caractere
		return "Nom de l'accord: " + accord + "\n" + "Notes : " 
				+ afficherTableauAccord();
				
	}

	/*
	 * Methode qui permet de lire et de jouer des accords
	 * 
	 * @param aucun parametre 
	 * 
	 * @return aucune valeur de retour 
	 */
	public void jouerAccord() {
		
		//Declaration et instancation du tableau des notes
		SourceDataLine[] line= new SourceDataLine[Notes.size()];
		
		//On instancie une ligne audio 
		AudioFormat audioFmt = 
				new AudioFormat(20500, 16, 1, true, true);
		
		//Parcourt chacune des notes de la collection de note
		for(int i=0;i<Notes.size();++i) {
			
			//Variable qui retient la position d'une note 
			//de la collection de notes
			int j;
			
			//On retient i dans une variable j pour le thread
			j=i;
			
			//Ouverture des lignes
			try {
				
				//Chaque case du tableau est une ligne audio
				line[j] = AudioSystem.getSourceDataLine(audioFmt);
				
				//On ouvre la ligne du tableau 
				line[j].open(audioFmt);


			//Si il y a une erreur lors de l'ouverture des lignes	
			} catch (LineUnavailableException lue) {
				System.out.println("# Erreur : impossible de trouver une"
									+ " ligne de sortie audio au format: ");
	                               
				System.out.println("#          " +audioFmt);
				System.exit(1);
			}
			
			//On commence le thread qui lit les notes 
			Thread t = new Thread(new Runnable() {

	            @Override
	            public void run() {
				
	            //Permet de commencer la lecture de la ligne
				line[j].start();
			
				//On obtient la note selon la position j
				Note note=Notes.get(j);
				
				//On joue la note sur une ligne
				TestDeSonMain.jouer(line[j],note.getNom_()
									,Constantes.INTENSITE_ACCORD 
									,note.getDuree());
				
			}

	            });

	            // D�marrage du Thread.
	            t.start();	

		}
		

	}
	/*
	 * Methode qui permet d'initialiser un accord 
	 */
	public void initAccord() {
		
		accord= null;
		
		Notes= new ArrayList<Note>();
	}

	

}

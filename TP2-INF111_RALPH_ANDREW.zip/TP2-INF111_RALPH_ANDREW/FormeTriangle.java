package musique;

/*
 * La classe FormeTriangle est une classe enfant de la classe parent FormeOnde
 */
public class FormeTriangle extends FormeOnde{
	
	
	/*
	 * Methode qui permet de calculer la frequence 
	 * 
	 * @param i de type integer 
	 * 
	 * @return valeurRetour 
	 */
	public double echantillon(int i) {
		
		//Valeur de retour
		double valeurRetour;
		
		//On calcule la periode
		double periode=valeurPeriode();
		
		//On calcule la valeur de r
		double r= valeurR(i);
		
		//Si la valeur de r est plus petit que 0
		if(r<0) {
			
			//On incremente la valeur de r
			r+=periode;
		}
		
		///Si r est plus petit ou egale au quart de la periode
		if(r<=(periode/4)) {
			
			//La valeur de retour est 4 fois la valeur 4 divise par la periode
			valeurRetour= ((r*4)/periode);
		}
		//Sinon si la valeur de r est plus petite ou egale a 3 fois la periode
		//divise par 4
		else if(r<=((3*periode)/4)) {
			
			//On decremente la valeur de r par le quart de la periode
			r-=periode/4;
			
			//On calcule la valeur de retour
			valeurRetour= 1-((r*4)/periode);
		}
		//Sinon 
		else {
			
			//On decremente la valeur de r par 3 fois la periode divise par 4
			r-=((3*periode)/4);
			
			//On calcule la valeur de retour
			valeurRetour= -1+((r*4)/periode);
		}
		
		//On retourne la valeur de retour
		return valeurRetour;
	}
	/*
	 * Constructeur par copie d'attributs
	 * 
	 * @param frequence
	 * 
	 * @param frequenceEchantillonnage
	 */
	public FormeTriangle(double frequence,double frequenceEchantillonnage) {
		
		//On utilise le constructeur par copie d'attribut de la classe parent
		super(frequence,frequenceEchantillonnage);
	}


}

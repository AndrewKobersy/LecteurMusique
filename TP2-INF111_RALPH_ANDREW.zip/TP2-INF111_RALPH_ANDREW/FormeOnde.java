package musique;


public abstract class FormeOnde {
	
	/*
	 * Attribut privee de la classe FormeOnde
	 */
	private double frequence;
	private double frequenceEchantillonnage;
	
	
	/*
	 * Constructeur par copie d'attributs
	 * 
	 * @param frequence de type double
	 * 
	 * @param frequenceEchantillonnage de type double
	 * 
	 * @return aucune valeur de retour
	 */
	public FormeOnde(double frequence, double frequenceEchantillonnage) {
		
		//On copie la frequence dans l'attribut de la classe FormeOnde
		this.frequence=frequence;
		
		//On copie la frequence d'echantillonnage dans l'attribut 
		//de la classe FormeOnde
		this.frequenceEchantillonnage=frequenceEchantillonnage;
		
	}
	
	/*
	 * Accesseurs pour frequence
	 * 
	 * @param aucun parametre 
	 * 
	 * @return on retourne la frequence
	 */
	public double getFrequence() {
		
		return frequence;
	}
	
	/*/
	 * Accesseurs pour frequence echantillonnage
	 */
	public double getFrequenceEchantillonnage() {
		
		return frequenceEchantillonnage;
	}
	
	/*
	 * Constructeur par defaut de la classe FormeOnde
	 * 
	 * @param aucun paramtre
	 * 
	 * @return aucune valeur de retour
	 */
	public FormeOnde() {
		
		frequence=0;
		frequenceEchantillonnage=0;
	}
	
	/*
	 * Methode qui calcule r grace a des frequences
	 * 
	 * @param i de type integer 
	 * 
	 * @return on retourne la valeur R 
	 */
	public double valeurR(int i) {
		
		//On calcule la periode
		double periode= valeurPeriode();
		
		//On calcule la valeur r
		double r=Math.IEEEremainder((i/frequenceEchantillonnage),periode);
		
		//On retourne la valeur r
		return r;
	}
	
	/*
	 * Methode qui permet de calculer la periode 
	 * 
	 * @param aucun parametre 
	 * 
	 * @return on retourn l'inverse de la frequence
	 */
	public double valeurPeriode() {
		
		//On retourne l'inverse de la frequence
		return 1/frequence;
	}
	/*
	 * Methode echantillon mais qui est utilise par les classes enfants et non 
	 * la classe parent
	 */
	public abstract double echantillon(int i);
	
	
		

}

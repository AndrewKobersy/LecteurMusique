package musique;

import java.util.Vector;

public class Constantes {
	
		// 1 minute.
		public static final int MIN_EN_MS = 60000;
		
		//Message du premier choix 
		public static final String PREMIER_CHOIX 
									= "Selectionner une piece a jouer";
		
		//Message du deuxieme choix 
		public static final String DEUXIEME_CHOIX 
									= "Jouer la derniere piece selectionnee";
		
		//Message du troisieme choix 
		public static final String TROISIEME_CHOIX 
									= "Quitter";
		
		//Message d'erreur 
		public static final String MESSAGE_ERREUR  
									= "Veuillez selectionnez une piece svp!";
		
		//Message pour quitter le menu chanson
		public static final String MESSAGE_QUITTER
									= "Au revoir et a la prochaine!";
		
		//Intensite de l'accord 
		public static final double INTENSITE_ACCORD = 0.3;

	}


